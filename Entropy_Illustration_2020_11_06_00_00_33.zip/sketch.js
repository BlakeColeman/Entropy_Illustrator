let aslider;
a = 0;
First = 0;
Second = 0;
Third = 0;
Fourth = 0;

function setup() {
  createCanvas(400, 400);
  aslider = createSlider(0, 3, 0)
  aslider.position(20, 20)
  textSize(30);
  frameRate(1);
}

function draw() {
  background(256);
  entropy();
  a = aslider.value();
  words();
}
//Prints Words Under Slider and Counters
function words() {
  fill(0, 102, 153);
  text('Min', 10, 60);
  text('Max', 100, 60);
  fill(0, 0, 0);
  text('First : ', 225, 30)
  text(First, 350, 30)
  text('Second: ', 225, 60)
  text(Second, 350, 60)
  text('Third : ', 225, 90)
  text(Third, 350, 90)
  text('Fourth: ', 225, 120)
  text(Fourth, 350, 120)
}
//Takes input from Slider and Randomizes it
function entropy() {
  First = 0;
  Second = 0;
  Third = 0;
  Fourth = 0;
  for (let i = 0; i < 400; i++) {
    if (a == 0) {
      zero(i);
    } else if (a == 1) {
      one(i);
    } else if (a == 2) {
      two(i);
    } else if (a == 3) {
      three(i);
    }
  }
}

//function for when slider is zero, 100% chance output will be 0
function zero(i) {
  b = 0;
  stroke(b);
  First++
  line(400, i, 0, i);
}
//function for when slider is one, 50% chance output will be 0, 25% output will be 100, 10% chance output will be 200, 15% chance output will be 255
function one(i) {
  r = random(1)
  if (r < 0.5) {
    b = 0
    First++
    stroke(b)
    line(400, i, 0, i)
  } else if (r < 0.75) {
    b = 100;
    Second++
    stroke(b);
    line(400, i, 0, i);
  } else if (r < 0.85) {
    b = 200;
    Third++
    stroke(b);
    line(400, i, 0, i);
  } else {
    b = 255;
    Fourth++
    stroke(b);
    line(400, i, 0, i);
  }
}
//function for when slider is two, 40% chance output will be 0, 20% output will be 100, 20% chance output will be 200, 20% chance output will be 255
function two(i) {
  r = random(1)
  if (r < 0.40) {
    b = 0;
    First++
    stroke(b);
    line(400, i, 0, i);
  } else if (r < 0.60) {
    b = 100;
    Second++
    stroke(b);
    line(400, i, 0, i);
  } else if (r < 0.80) {
    b = 200;
    Third++
    stroke(b);
    line(400, i, 0, i);
  } else {
    b = 255;
    Fourth++
    stroke(b);
    line(400, i, 0, i);
  }
  //function for when slider is one, 25% chance output will be 0, 25% output will be 100, 25% chance output will be 200, 25% chance output will be 255
}

function three(i) {
  r = random(1)
  if (r < 0.25) {
    b = 0;
    First++
    stroke(b);
    line(400, i, 0, i);
  } else if (r < 0.50) {
    b = 100;
    Second++
    stroke(b);
    line(400, i, 0, i);
  } else if (r < 0.75) {
    b = 200;
    Third++
    stroke(b);
    line(400, i, 0, i);
  } else {
    b = 255;
    Fourth++
    stroke(b);
    line(400, i, 0, i);
  }
}